rm -rf build/
cmake -S . -B build/target -DCMAKE_C_COMPILER=aarch64-linux-gnu-gcc
cmake --build build/target
cp build/target/app/light_sampler ~/ENSC351/public/myApps/
