cmake -S . -B build/target -DCMAKE_C_COMPILER=aarch64-linux-gnu-gcc
cmake --build build/target
cp build/target/app/reaction_timer ~/ENSC351/public/myApps/
