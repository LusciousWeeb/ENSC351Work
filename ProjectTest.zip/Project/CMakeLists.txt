# CMake build configuration for the root of the project
cmake_minimum_required(VERSION 3.18)
project(yaw_control VERSION 1.0 DESCRIPTION "ENSC 351 remote camera: yaw subsystem" LANGUAGES C)

# Compiler options (inherited by sub-folders)
set(CMAKE_C_STANDARD 11)
add_compile_options(-Wall -Werror -Wpedantic -Wextra)
add_compile_options(-fdiagnostics-color)

# Address sanitizer (slower, catches memory bugs). Uncomment both lines to enable.
# The board needs `sudo apt install libasan6` before this build will run.
# add_compile_options(-fsanitize=address)
# add_link_options(-fsanitize=address)

# Enable PThread library for linking
add_compile_options(-pthread)
add_link_options(-pthread)

# What folders to build
add_subdirectory(hal)
add_subdirectory(app)
