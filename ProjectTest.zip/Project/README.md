# Remote-Controlled Auto-Tracking Camera: Yaw Subsystem

ENSC 351 project. This folder holds the yaw (pan) control code for the BeagleY-AI, laid out like the course assignments (`as1`, `as2`).

## Layout

```
.
├── CMakeLists.txt          # root build file (compiler flags, sub-folders)
├── buildScript.sh          # cross-compiles and copies the binary to the shared folder
├── hal/                    # hardware modules
│   ├── CMakeLists.txt      # builds all of hal/src into the "hal" library
│   ├── include/hal/        # headers: joystick.h, button.h, rotary_encoder.h, servo.h
│   └── src/                # joystick.c, button.c, rotary_encoder.c, servo.c
└── app/                    # application code
    ├── CMakeLists.txt
    ├── include/            # yaw_control.h
    └── src/                # main.c, yaw_control.c
```

- `hal/joystick.c` and `hal/rotary_encoder.c` come from the course assignments (`as1`, `as2`).
- `hal/button.c` is rewritten to read the real button (the course version is a random stub).
- `hal/servo.c` is new, modelled on the course's `pwm_led.c`.

## Hardware (yaw only)

- BeagleY-AI
- MCP3208 ADC over SPI0 (CE0). Joystick VRx goes to CH0, VRy to CH1, and the joystick VCC is 3.3 V.
- SG90 yaw servo on GPIO12 (pin 32). Powered from its own 5 V supply, with grounds shared.
- Rotary encoder: CLK/DT (`ROTARY_ENCODER` lines), turn to nudge yaw by 1° per click.
- Push button: lock toggle. Set `BUTTON_LINE_NAME` in `hal/src/button.c` after checking the line name.
- Potentiometer: not used for now.

Before wiring, check the header line names on the board:

```bash
gpiofind hat-36-gpio
gpiofind hat-11-gpio
```

## Build and run

On the VM, from the project root:

```bash
./buildScript.sh
```

Then on the BeagleY-AI, run the copied binary (it must be run as root for PWM):

```bash
sudo ./yaw_control
```

Ctrl+C stops it.

## Notes

- The encoder and button use libgpiod v2. The VM needs the ARM64 `libgpiod.a` that `hal/CMakeLists.txt` links against.
- Adding or removing `.c` files in `hal/src` or `app/src` needs a CMake re-run. `buildScript.sh` does this every time.
- If the build fails with `-Werror` warnings, fix the warning rather than removing the flag.

## Status

- [ ] SPI enabled and joystick reads working
- [ ] Servo moves on the PWM channel
- [ ] Joystick moves yaw
- [ ] Encoder nudges yaw
- [ ] Button toggles the lock
