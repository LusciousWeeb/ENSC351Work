// hal/servo.h
// Hardware abstraction for the SG90 yaw servo, driven by hardware PWM.
//
// Typical use:
//   Servo_init();              // once at startup, starts at 90 degrees
//   Servo_setAngle(45);        // 0..180, values outside are clamped
//   Servo_cleanup();           // once at shutdown; output is turned off

#ifndef HAL_SERVO_H
#define HAL_SERVO_H

// Set up the PWM channel (exports it if needed) and centre the servo.
// Exits the program with an error message if the PWM can't be configured.
void Servo_init(void);

// Move the servo to an angle in degrees, 0..180 (clamped).
void Servo_setAngle(int degrees);

// Turn the PWM output off.
void Servo_cleanup(void);

#endif // HAL_SERVO_H
