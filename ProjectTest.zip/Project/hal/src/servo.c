// hal/src/servo.c
// Drives the SG90 through the BeagleY-AI hardware PWM sysfs interface.
// The PWM channel is exported with beagle-pwm-export, the same way as the LED
// module (pin 32 = GPIO12 = hat-32).

#include "hal/servo.h"

#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define SERVO_SYSFS_DIR   "/dev/hat/pwm/GPIO12"
#define SERVO_EXPORT_CMD  "beagle-pwm-export --pin hat-32"
#define SYSFS_PATH_MAX    256

#define PERIOD_NS         20000000L   // 50 Hz
#define MIN_PULSE_NS       1000000L   // 0 degrees; tune for your SG90
#define MAX_PULSE_NS       2000000L   // 180 degrees; tune for your SG90
#define CENTRE_DEG            90

static bool s_isInitialized = false;

// Write a number to one of the PWM sysfs files. sysfs reports bad values
// when the file is closed, so check fclose() too.
static void writeValue(const char *fileName, long long value)
{
    char path[SYSFS_PATH_MAX];
    snprintf(path, sizeof(path), "%s/%s", SERVO_SYSFS_DIR, fileName);

    FILE *file = fopen(path, "w");
    if (file == NULL) {
        fprintf(stderr, "Servo: unable to open %s: %s\n", path, strerror(errno));
        exit(EXIT_FAILURE);
    }
    bool ok = (fprintf(file, "%lld\n", value) > 0);
    if (fclose(file) != 0) {
        ok = false;
    }
    if (!ok) {
        fprintf(stderr, "Servo: unable to write %lld to %s: %s\n",
                value, path, strerror(errno));
        exit(EXIT_FAILURE);
    }
}

void Servo_init(void)
{
    if (s_isInitialized) {
        return;
    }

    // Export the PWM channel if its sysfs folder isn't there yet.
    if (access(SERVO_SYSFS_DIR, F_OK) != 0) {
        if (system(SERVO_EXPORT_CMD) != 0) {
            fprintf(stderr, "Servo: '%s' failed\n", SERVO_EXPORT_CMD);
            exit(EXIT_FAILURE);
        }
    }

    // Course guide: zero the duty cycle before changing the period.
    writeValue("duty_cycle", 0);
    writeValue("period", PERIOD_NS);
    Servo_setAngle(CENTRE_DEG);
    writeValue("enable", 1);

    s_isInitialized = true;
}

void Servo_setAngle(int degrees)
{
    if (degrees < 0) {
        degrees = 0;
    }
    if (degrees > 180) {
        degrees = 180;
    }
    long long pulse = MIN_PULSE_NS
                    + (MAX_PULSE_NS - MIN_PULSE_NS) * degrees / 180;
    writeValue("duty_cycle", pulse);
}

void Servo_cleanup(void)
{
    if (!s_isInitialized) {
        return;
    }
    writeValue("enable", 0);
    s_isInitialized = false;
}
