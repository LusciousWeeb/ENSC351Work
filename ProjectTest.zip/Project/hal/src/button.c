// hal/src/button.c
// Reads the push button with libgpiod (v2), the same library as the encoder.
// The button is wired from the GPIO line to GND, and the line is pulled up,
// so pressed = line reads low.
//
// Find the line name on the board with:  gpiofind hat-NN-gpio
// (NN = header pin number), then set BUTTON_LINE_NAME to that name.

#include "hal/button.h"

#include <assert.h>
#include <gpiod.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

// Set this to the line name for the button's header pin.
#define BUTTON_LINE_NAME  "GPIO7"
#define MAX_GPIO_CHIPS    16

static bool is_initialized = false;
static struct gpiod_chip *s_chip = NULL;
static struct gpiod_line_request *s_request = NULL;
static unsigned int s_offset = 0;

// Look for a line called `name` (case-insensitive) on this chip.
static bool findLine(struct gpiod_chip *chip, const char *name, unsigned int *offset)
{
    struct gpiod_chip_info *info = gpiod_chip_get_info(chip);
    if (info == NULL) {
        return false;
    }
    size_t numLines = gpiod_chip_info_get_num_lines(info);
    gpiod_chip_info_free(info);

    for (unsigned int i = 0; i < numLines; i++) {
        struct gpiod_line_info *lineInfo = gpiod_chip_get_line_info(chip, i);
        if (lineInfo == NULL) {
            continue;
        }
        const char *lineName = gpiod_line_info_get_name(lineInfo);
        bool match = (lineName != NULL && strcasecmp(lineName, name) == 0);
        gpiod_line_info_free(lineInfo);
        if (match) {
            *offset = i;
            return true;
        }
    }
    return false;
}

void button_init(void)
{
    assert(!is_initialized);

    // Search the GPIO chips for the button's line.
    for (int c = 0; c < MAX_GPIO_CHIPS && s_chip == NULL; c++) {
        char path[32];
        snprintf(path, sizeof(path), "/dev/gpiochip%d", c);
        struct gpiod_chip *candidate = gpiod_chip_open(path);
        if (candidate == NULL) {
            continue;
        }
        if (findLine(candidate, BUTTON_LINE_NAME, &s_offset)) {
            s_chip = candidate;
        } else {
            gpiod_chip_close(candidate);
        }
    }
    if (s_chip == NULL) {
        fprintf(stderr, "Button: no line named '%s' (check with gpiofind)\n",
                BUTTON_LINE_NAME);
        exit(EXIT_FAILURE);
    }

    struct gpiod_line_settings *settings = gpiod_line_settings_new();
    struct gpiod_line_config *lineConfig = gpiod_line_config_new();
    struct gpiod_request_config *requestConfig = gpiod_request_config_new();
    if (settings == NULL || lineConfig == NULL || requestConfig == NULL) {
        fprintf(stderr, "Button: out of memory\n");
        exit(EXIT_FAILURE);
    }

    gpiod_line_settings_set_direction(settings, GPIOD_LINE_DIRECTION_INPUT);
    gpiod_line_settings_set_bias(settings, GPIOD_LINE_BIAS_PULL_UP);
    gpiod_line_config_add_line_settings(lineConfig, &s_offset, 1, settings);
    gpiod_request_config_set_consumer(requestConfig, "yaw_button");

    s_request = gpiod_chip_request_lines(s_chip, requestConfig, lineConfig);

    gpiod_line_settings_free(settings);
    gpiod_line_config_free(lineConfig);
    gpiod_request_config_free(requestConfig);

    if (s_request == NULL) {
        fprintf(stderr, "Button: unable to request line '%s'\n", BUTTON_LINE_NAME);
        exit(EXIT_FAILURE);
    }
    is_initialized = true;
}

bool button_is_button_pressed(void)
{
    assert(is_initialized);
    // Pull-up with the button to GND: a press pulls the line low (INACTIVE).
    return gpiod_line_request_get_value(s_request, s_offset)
           == GPIOD_LINE_VALUE_INACTIVE;
}

void button_cleanup(void)
{
    assert(is_initialized);
    gpiod_line_request_release(s_request);
    gpiod_chip_close(s_chip);
    s_request = NULL;
    s_chip = NULL;
    is_initialized = false;
}
