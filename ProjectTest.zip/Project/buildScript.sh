#!/bin/bash
# Cross-compile the yaw control app for the BeagleY-AI and copy it to the shared folder.
set -e

rm -rf build/
cmake -S . -B build/target -DCMAKE_C_COMPILER=aarch64-linux-gnu-gcc
cmake --build build/target
cp build/target/app/yaw_control ~/ENSC351/public/myApps/
