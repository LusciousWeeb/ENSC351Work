// app/include/yaw_control.h
// Yaw (pan) control: joystick moves the camera left/right, the rotary encoder
// nudges it by one degree per click, and the button toggles a software lock
// that holds the current angle and ignores the joystick and encoder.

#ifndef YAW_CONTROL_H
#define YAW_CONTROL_H

#include <stdbool.h>

// Call once after Joystick_initialize(), Servo_init() and RotaryEncoder_init().
void YawControl_init(void);

// Move yaw from the joystick. Call every loop tick with dt in seconds.
void YawControl_updateFromJoystick(double dt);

// Toggle the software lock.
void YawControl_toggleLock(void);

bool YawControl_isLocked(void);

// Current yaw angle in degrees.
double YawControl_getAngle(void);

#endif // YAW_CONTROL_H
