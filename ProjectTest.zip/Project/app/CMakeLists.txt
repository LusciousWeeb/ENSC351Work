# Build the yaw control application
include_directories(include)

add_executable(yaw_control src/main.c src/yaw_control.c)

# Link the hardware abstraction layer
target_link_libraries(yaw_control PRIVATE hal)
