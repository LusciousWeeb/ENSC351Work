// app/src/main.c
// Yaw control entry point. Ctrl+C stops the program and cleans up the hardware.

#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>

#include "hal/button.h"
#include "hal/joystick.h"
#include "hal/rotary_encoder.h"
#include "hal/servo.h"
#include "yaw_control.h"

#define LOOP_PERIOD_US   10000   // 10 ms per tick
#define DEBOUNCE_TICKS       3   // button must read the same value 3 ticks (30 ms)

static volatile sig_atomic_t s_running = 1;

static void onSignal(int sig)
{
    (void)sig;
    s_running = 0;
}

int main(void)
{
    signal(SIGINT, onSignal);
    signal(SIGTERM, onSignal);

    Joystick_initialize();
    Servo_init();
    button_init();
    RotaryEncoder_init();
    YawControl_init();

    bool stable = false;        // debounced button state
    bool candidate = false;     // latest raw reading being checked
    int candidateCount = 0;

    while (s_running) {
        bool raw = button_is_button_pressed();
        if (raw == candidate) {
            if (candidateCount < DEBOUNCE_TICKS) {
                candidateCount++;
            }
        } else {
            candidate = raw;
            candidateCount = 1;
        }

        if (candidateCount >= DEBOUNCE_TICKS && candidate != stable) {
            stable = candidate;
            if (stable) {                       // act on the press, not the release
                YawControl_toggleLock();
                printf("%s at %.1f deg\n",
                       YawControl_isLocked() ? "LOCKED" : "UNLOCKED",
                       YawControl_getAngle());
            }
        }

        YawControl_updateFromJoystick(LOOP_PERIOD_US / 1000000.0);
        usleep(LOOP_PERIOD_US);
    }

    RotaryEncoder_cleanup();
    button_cleanup();
    Servo_cleanup();
    Joystick_cleanup();
    return 0;
}
