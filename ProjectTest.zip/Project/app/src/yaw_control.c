// app/src/yaw_control.c

#include "yaw_control.h"

#include <pthread.h>

#include "hal/joystick.h"
#include "hal/rotary_encoder.h"
#include "hal/servo.h"

#define YAW_START_DEG       90.0
#define YAW_MIN_DEG          0.0
#define YAW_MAX_DEG        180.0
#define JOYSTICK_RATE_DPS   60.0   // degrees per second while the stick is held
#define ENCODER_STEP_DEG     1.0   // degrees per encoder click

// The encoder callback runs on the encoder's thread, so these are shared
// between threads and must only be touched while holding s_lock.
static pthread_mutex_t s_lock = PTHREAD_MUTEX_INITIALIZER;
static double s_yaw = YAW_START_DEG;
static bool s_locked = false;

// Caller must hold s_lock.
static void setYawLocked(double deg)
{
    if (deg < YAW_MIN_DEG) {
        deg = YAW_MIN_DEG;
    }
    if (deg > YAW_MAX_DEG) {
        deg = YAW_MAX_DEG;
    }
    s_yaw = deg;
    Servo_setAngle((int)(s_yaw + 0.5));
}

static void onEncoderStep(int direction)
{
    pthread_mutex_lock(&s_lock);
    if (!s_locked) {
        setYawLocked(s_yaw + direction * ENCODER_STEP_DEG);
    }
    pthread_mutex_unlock(&s_lock);
}

void YawControl_init(void)
{
    pthread_mutex_lock(&s_lock);
    setYawLocked(s_yaw);
    pthread_mutex_unlock(&s_lock);

    RotaryEncoder_setStepCallback(onEncoderStep);
}

void YawControl_updateFromJoystick(double dt)
{
    JoystickDirection dir = Joystick_getDirection();

    // Up and down are for pitch, so only left and right move yaw here.
    double sign = 0.0;
    if (dir == JOYSTICK_RIGHT) {
        sign = 1.0;
    } else if (dir == JOYSTICK_LEFT) {
        sign = -1.0;
    }
    if (sign == 0.0) {
        return;
    }

    pthread_mutex_lock(&s_lock);
    if (!s_locked) {
        setYawLocked(s_yaw + sign * JOYSTICK_RATE_DPS * dt);
    }
    pthread_mutex_unlock(&s_lock);
}

void YawControl_toggleLock(void)
{
    pthread_mutex_lock(&s_lock);
    s_locked = !s_locked;
    pthread_mutex_unlock(&s_lock);
}

bool YawControl_isLocked(void)
{
    pthread_mutex_lock(&s_lock);
    bool locked = s_locked;
    pthread_mutex_unlock(&s_lock);
    return locked;
}

double YawControl_getAngle(void)
{
    pthread_mutex_lock(&s_lock);
    double angle = s_yaw;
    pthread_mutex_unlock(&s_lock);
    return angle;
}
